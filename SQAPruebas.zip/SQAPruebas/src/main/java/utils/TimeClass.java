package utils;

public class TimeClass {

    public static void waits(int wait){
        try{
            Thread.sleep(wait*1000L);
        } catch (InterruptedException e){
            e.printStackTrace();
            Thread.currentThread().interrupt();
        }
    }
}
