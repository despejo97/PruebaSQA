package userinterfaces;

import net.thucydides.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;


public class SegundoProducto extends PageObject {

    public static final Target DESCRIPCION_SEGUNDO_PRODUCTO = Target.the("Redireccionamiento segundo producto").locatedBy("//img[@src=\"https://sanangel.com.co/wp-content/uploads/2019/02/destellos-2-300x300.jpg\"]");
    public static final Target COLOR_ROJO = Target.the("Elegir Color rojo").locatedBy("//li[@title=\"Rojo\"]");
    public final static Target IMG_PRODUCTO_ERVATE= Target.the("Presencia de elemento").locatedBy("//img[@src=\"https://sanangel.com.co/wp-content/uploads/2020/11/evora-new-1-300x300.jpg\"]");
    public final static Target IMG_PRODUCTO_DESTELLO= Target.the("Presencia de destello").locatedBy("//img[@src=\"https://sanangel.com.co/wp-content/uploads/2019/02/destellos-2-300x300.jpg\"]");

    public final static Target TXT_CUPONES= Target.the("Presencia del elemento cupones").locatedBy("//a[contains(text(),'Haz clic aquí para introducir tu código')]");
}
