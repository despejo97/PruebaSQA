package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Open;
import org.openqa.selenium.WebDriver;
import questions.ValidacionElementoClass;
import tasks.BuscarProducto;
import userinterfaces.HomePage;
import utils.TimeClass;

import static constants.ConstantClass.TIME_SHORT;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.isPresent;
import static net.serenitybdd.screenplay.questions.WebElementQuestion.the;
import static userinterfaces.SegundoProducto.IMG_PRODUCTO_DESTELLO;
import static userinterfaces.SegundoProducto.IMG_PRODUCTO_ERVATE;


public class StepClass {
   @Managed(driver="chrome")
   private WebDriver driver;
   private Actor actor= Actor.named("Global");
   private HomePage homePage = new HomePage();


    @Given("^que un cliente ingresa a la pagina web$")
    public void queUnClienteAccedeALaWebDeCompras() {
        actor.can(BrowseTheWeb.with(driver));
        actor.wasAbleTo(Open.browserOn(homePage));
        driver.manage().window().maximize();
        TimeClass.waits(TIME_SHORT);
        }
    @When("^el agrega el producto al carro con cantidad (.*) y agrega otro producto al carro con cantidad (.*)$")
    public void agregaElProductoAlCarrito(String cantidad1, String cantidad2) {

        actor.wasAbleTo(
                BuscarProducto.conDescripcion(cantidad1, cantidad2)
        );
        TimeClass.waits(TIME_SHORT);
    }
    @Then("^debe de guardar el producto de manera exitosa$")
    public void elVeLosProductosEnElCarritoDeCompras() {
      actor.should(
              seeThat(the(IMG_PRODUCTO_ERVATE), isPresent()),
              seeThat(the(IMG_PRODUCTO_DESTELLO),isPresent()));
        TimeClass.waits(TIME_SHORT);
    }
}
