package questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import org.openqa.selenium.NoSuchElementException;
import userinterfaces.SegundoProducto;

public class ValidacionElementoClass implements Question<Boolean> {
    @Override
    public Boolean answeredBy(Actor actor) {
        try {
            return (BrowseTheWeb.as(actor).find(SegundoProducto.IMG_PRODUCTO_ERVATE).isPresent()&&BrowseTheWeb.as(actor).find(SegundoProducto.IMG_PRODUCTO_DESTELLO).isPresent());
        } catch (NoSuchElementException e) {
            System.out.println(e);
        }
        return false;
    }
}
