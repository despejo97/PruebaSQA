package tasks;


import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Clear;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Scroll;




import static net.serenitybdd.screenplay.Tasks.instrumented;
import static userinterfaces.HomePage.*;
import static userinterfaces.SegundoProducto.*;


public class BuscarProducto implements Task {
    private String cantidad1;
    private String cantidad2;

    public BuscarProducto(String cantidad1, String cantidad2){
        this.cantidad1= cantidad1;
        this.cantidad2= cantidad2;
    }



    @Override
    public <T extends Actor> void performAs(T actor) {
    actor.attemptsTo(
            Click.on(DESCRIPCION_PRODUCTO),
            Click.on(BUTTON_COLOR),
            Click.on(BUTTON_DAY),
            Click.on(BUTTON_HOUR),
            Scroll.to(BUTTON_HOUR),
            Clear.field(INPUT_CANTIDAD),
            Enter.theValue(cantidad1).into(INPUT_CANTIDAD),
            Click.on(BUTTON_CARRITO),
            Click.on(IMG_INDEX),
            Scroll.to(DESCRIPCION_SEGUNDO_PRODUCTO),
            Click.on(DESCRIPCION_SEGUNDO_PRODUCTO),
            Click.on(COLOR_ROJO),
            Click.on(BUTTON_DAY),
            Click.on(BUTTON_HOUR),
            Scroll.to(BUTTON_HOUR),
            Clear.field(INPUT_CANTIDAD),
            Enter.theValue(cantidad2).into(INPUT_CANTIDAD),
            Scroll.to(COLOR_ROJO),
            Click.on(BUTTON_CARRITO),
            Scroll.to(TXT_CUPONES)
    );
    }
    public static BuscarProducto conDescripcion(String cantidad1, String cantidad2) {
        return instrumented(BuscarProducto.class, cantidad1, cantidad2);
    }
}
