package userinterfaces;

import net.serenitybdd.annotations.DefaultUrl;
import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.pages.PageObject;
@DefaultUrl("https://sanangel.com.co/")
public class HomePage extends PageObject {
    public static final Target DESCRIPCION_PRODUCTO= Target.the("Descripción primer producto").locatedBy("//img[@src=\"https://sanangel.com.co/wp-content/uploads/2020/11/evora-new-1-300x300.jpg\"]");
    public static final Target INPUT_CANTIDAD= Target.the("Cantidad de elementos a colocar dentro del producto").locatedBy("/html[1]/body[1]/div[2]/main[1]/div[2]/div[1]/div[2]/form[1]/div[1]/div[1]/div[2]/input[1]");

    public static final Target BUTTON_CARRITO= Target.the("Botón de agregar carrito").locatedBy("/html[1]/body[1]/div[2]/main[1]/div[2]/div[1]/div[2]/form[1]/div[1]/div[1]/div[2]/button[1]");

    public static final Target BUTTON_COLOR= Target.the("Botón de color amarillo").locatedBy("//li[@data-value=\"amarillo\"]");
    public static final Target BUTTON_DAY= Target.the("Botón para seleccionar día").locatedBy("//span[contains(text(),'Mañana')]");
    public static final Target BUTTON_HOUR= Target.the("Botón para escoger la hora").locatedBy("/html[1]/body[1]/div[2]/main[1]/div[2]/div[1]/div[2]/div[2]/div[1]/div[2]/div[2]/a[1]");
    public static final Target IMG_INDEX= Target.the("Elemento para redigir al usuario a la página index").locatedBy("//a[@href=\"https://sanangel.com.co/\"]");


}
