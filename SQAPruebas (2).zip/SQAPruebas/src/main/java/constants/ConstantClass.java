package constants;

public class ConstantClass {
    public static final int TIME_SHORT= 5;
}
